package com.kanjiwidget.widget

import android.content.Context
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.glance.GlanceId
import androidx.glance.GlanceModifier
import androidx.glance.action.ActionParameters
import androidx.glance.action.actionRunCallback
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.GlanceAppWidgetManager
import androidx.glance.appwidget.action.ActionCallback
import androidx.glance.appwidget.provideContent
import androidx.glance.layout.*
import androidx.glance.text.Text
import androidx.glance.text.TextStyle
import androidx.glance.unit.ColorProvider
import com.kanjiwidget.data.KanjiRepository
import kotlin.random.Random

class RefreshKanjiAction : ActionCallback {
    override suspend fun onAction(context: Context, glanceId: GlanceId, parameters: ActionParameters) {
        val prefs = context.getSharedPreferences("widget", Context.MODE_PRIVATE)
        prefs.edit().putInt("index", Random.nextInt(KanjiRepository.items.size)).apply()
        KanjiAppWidget().update(context, glanceId)
    }
}

class KanjiAppWidget : GlanceAppWidget() {
    override suspend fun provideGlance(context: Context, id: GlanceId) {
        provideContent { WidgetContent(context) }
    }
}

@Composable
private fun WidgetContent(context: Context) {
    val prefs = context.getSharedPreferences("widget", Context.MODE_PRIVATE)
    val index = prefs.getInt("index", 0).coerceIn(0, KanjiRepository.items.lastIndex)
    val item = KanjiRepository.items[index]
    Column(
        modifier = GlanceModifier.fillMaxSize().padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(item.character, style = TextStyle(fontSize = 38.sp))
        Text(item.hiragana, style = TextStyle(fontSize = 14.sp))
        Text(item.meaning, style = TextStyle(fontSize = 14.sp))
        Row(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("N5", style = TextStyle(fontSize = 11.sp))
            Spacer(GlanceModifier.width(12.dp))
            Text("↻", style = TextStyle(fontSize = 18.sp), modifier = GlanceModifier.clickable(actionRunCallback<RefreshKanjiAction>()))
        }
    }
}
