package com.kanjiwidget.data

data class Kanji(
    val number: Int,
    val character: String,
    val hiragana: String,
    val meaning: String,
    val jlpt: String
)
