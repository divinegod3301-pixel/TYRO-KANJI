# Dataset status

This build includes the exact 307 Kanji entries available in the previously supplied `kanji_320_interactive_quiz(1).html` source. That source is titled 320 Kanji but actually contains 307 entries. The remaining 13 entries are intentionally not invented. They must be supplied before this project can truthfully be called a complete 320-Kanji dataset.
